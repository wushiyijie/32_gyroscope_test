#ifndef TIM_H_
#define TIM_H_

#include "stm32f4xx_tim.h"
#include "sys.h"
#include "usart.h"

void Time1_Init(void);
void pwm_GPIO_init(void);
void tim1_init(void);
#endif

