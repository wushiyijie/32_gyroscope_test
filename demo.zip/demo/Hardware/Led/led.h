#ifndef LED_H_
#define LED_H_

#include <stm32f4xx.h>

void GPIO_init(void);

#endif

