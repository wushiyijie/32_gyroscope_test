#ifndef USART_H_
#define USART_H_

#include <stm32f4xx.h>
#include "stm32f4xx_usart.h"
#include "stdio.h"
#include "misc.h"
void Usart(int bind);



#endif
